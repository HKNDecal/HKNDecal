import socket


## THIS IS /AJ/
USERNAME="AJ"

def intro():
    print("~~~~Welcome to Decal Chat~~~~")
    print("Logged in as: ", USERNAME)

def server(host="localhost",port=59700,buf_size=10240):
    s = socket.socket()
    s.bind((host,port))
    s.listen()
    #print("Ready to receive at {0}:{1}".format(host,port))
    conn, addr = s.accept()
    
    #print("Connected by: {0}".format(addr))
    intro()

    while True:
        data = conn.recv(buf_size)
        if not data:
            print("[SERVER MSG]: Luke quit")
            conn, addr = s.accept()
        else:
            recvStr = data.decode()
            print('[{0}]: '.format(USERNAME), recvStr)
            sendStr = input("Type a message to reply: ")
            conn.sendall(sendStr.encode())
    conn.close()

if __name__ == "__main__":
    server()