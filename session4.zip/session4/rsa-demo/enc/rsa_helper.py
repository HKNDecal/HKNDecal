from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization


key = rsa.generate_private_key(public_exponent=65537,key_size=2048,backend=default_backend())
pub = key.public_key()
pubKey =  pub.public_bytes(encoding=serialization.Encoding.PEM,format=serialization.PublicFormat.SubjectPublicKeyInfo)
#print(pubKey.decode())

pem = key.private_bytes(encoding=serialization.Encoding.PEM,format=serialization.PrivateFormat.PKCS8,encryption_algorithm=serialization.BestAvailableEncryption(b'mypassword'))
#print(pem.decode())



superStr = "-----BEGIN PUBLIC KEY----- \
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA8KTcoDhW9ZYOtrOTL9Tn \
cPTt7WHFLQN3kHm31Kllnvo3OUFz6mbYmFTlCaFGcKymg0tvtvDxXFalPLab09dE \
RbpVhvIh1QFQ2OG9AWHtW94wIFLfnbnVO38pvFl1WDW8q2xbQOyvm/S9HoCSl9sF \
l9j3slUu+CyJdo38Ieo0PYhH55EFVhMCptCa9YjUGV/leIrmxYJRhwNA7fJ0CSZb \
U1mBgNMRkDsyiud/oVqjXXHRUzZZGHVN0FwGa4WlT2Km9q1hpDc+zw+K+2dfojrv \
Wk5IPmWjPSDmhwOsAih3tQSdotDfuQzvBKcO312HFec+BVh4jciMPn1j1KrFyXS0 \
LwIDAQAB \
-----END PUBLIC KEY-----"