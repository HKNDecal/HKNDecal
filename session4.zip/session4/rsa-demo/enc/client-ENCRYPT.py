import socket
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.serialization import load_pem_public_key
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes
from rsa_helper import superStr
## This is /LUKE/
USERNAME = "LUKE"

def RSA_setup():
    with open("rsa_priv","rb") as key_file:
        key = serialization.load_pem_private_key(key_file.read(),password=b'mypassword',backend=default_backend())
    #key = rsa.generate_private_key(public_exponent=65537,key_size=2048,backend=default_backend())
    pub = key.public_key()
    pubKey =  pub.public_bytes(encoding=serialization.Encoding.PEM,format=serialization.PublicFormat.SubjectPublicKeyInfo)
    return (key,pub,pubKey.decode())


def intro():
    print("~~~~Welcome to Decal Chat v2 RSA ENCRYPTED~~~~")
    print("Logged in as: {0}\n".format(USERNAME))

def client(host="localhost",port=59720,buf_size=10240):
    s = socket.socket()
    s.connect((host,port))
    intro()

    priv,pub,pubStr = RSA_setup()

    while True:
        myInput = input("Enter a message to send or type 'q'/'Q' to escape: ")
        if myInput.upper() == "Q":
            s.close()
            return
        msg = myInput.encode()
        ciphertext = pub.encrypt(msg,padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),algorithm=hashes.SHA256(),label=None))
        s.sendall(ciphertext)
        data = s.recv(buf_size)
        recvStr = priv.decrypt(data,padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),algorithm=hashes.SHA256(),label=None))
        recvStr = recvStr.decode()
        print('[AJ]: {0}'.format(recvStr))

if __name__ == "__main__":
    
    client()