import socket
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.serialization import load_pem_public_key
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes

from rsa_helper import superStr

## THIS IS /AJ/
USERNAME="AJ"

def intro():
    print("~~~~Welcome to Decal Chat~~~~")
    print("Logged in as: ", USERNAME)


def RSA_setup():
    with open("rsa_priv","rb") as key_file:
        key = serialization.load_pem_private_key(key_file.read(),password=b'mypassword',backend=default_backend())
    #key = rsa.generate_private_key(public_exponent=65537,key_size=2048,backend=default_backend())
    pub = key.public_key()
    pubKey =  pub.public_bytes(encoding=serialization.Encoding.PEM,format=serialization.PublicFormat.SubjectPublicKeyInfo)
    return (key,pub,pubKey.decode())




def server(host="localhost",port=59720,buf_size=10240):
    priv,pub,pubStr = RSA_setup()
    s = socket.socket()
    s.bind((host,port))
    s.listen()
    print("Ready to receive at {0}:{1}".format(host,port))
    conn, addr = s.accept()
    print("Connected by: {0}".format(addr))

   
    while True:
        data = conn.recv(buf_size)
        if not data:
            print("[SERVER LOG]: Host quit")
            conn, addr = s.accept()
        else:
            #STAGE 1: We don't yet have the RSA Public Key to encrypt
            recvStr = priv.decrypt(data,padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),algorithm=hashes.SHA256(),label=None))
            recvStr = recvStr.decode()
            print('[Luke]: ', recvStr)
            sendStr = input("Type a message to reply: ")
            sendThis = pub.encrypt(sendStr.encode(),padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),algorithm=hashes.SHA256(),label=None))
            conn.sendall(sendThis)

if __name__ == "__main__":
    #print(RSA_setup())
    server()