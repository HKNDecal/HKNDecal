import socket

## This is /LUKE/
USERNAME = "LUKE"
def intro():
    print("~~~~Welcome to Decal Chat~~~~")
    print("Logged in as: ", USERNAME)

def client(host="localhost",port=59700,buf_size=10240,enc=False):
    s = socket.socket()
    s.connect((host,port))
    intro()
    while True:
        myInput = input("Enter a message to send or type 'q'/'Q' to escape: ")
        if myInput.upper() == "Q":
            s.close()
            return
        s.sendall(myInput.encode())
        data = s.recv(buf_size)
        print("[AJ] said: ", data.decode())


if __name__ == "__main__":
    
    client()